mov ah, 09h
    mov bh, 0
    mov cx, 1000h
    mov al, 20h

    mov bl, 30h ; 30h = cyan, 20h = blue
    int 10h